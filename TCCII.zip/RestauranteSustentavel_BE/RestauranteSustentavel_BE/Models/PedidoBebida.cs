﻿namespace RestauranteSustentavel_BE.Models
{
    public class PedidoBebida
    {
        public int quantidade { get; set; }
        public int idBebida { get; set; }
        public int idPedido { get; set; }

    }
}
