﻿namespace RestauranteSustentavel_BE.Models
{
    public class IngredientePrato
    {
        public int idIngrediente { get; set; }
        public int idPrato { get; set; }
        public int quantidade { get; set; }
    }
}
