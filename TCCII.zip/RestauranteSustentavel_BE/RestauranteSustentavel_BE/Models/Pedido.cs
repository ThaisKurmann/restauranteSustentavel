﻿namespace RestauranteSustentavel_BE.Models
{
    public class Pedido
    {
        public string data { get; set; }
        public string hora { get; set; }
        public int id { get; set; }
        

        




    }
}
