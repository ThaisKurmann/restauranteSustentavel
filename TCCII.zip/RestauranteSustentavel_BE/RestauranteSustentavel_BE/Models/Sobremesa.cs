﻿namespace RestauranteSustentavel_BE.Models
{
    public class Sobremesa
    {
        public string nome { get; set; }
        public int porcao { get; set; }
        public int id { get; set; }
        public float preco { get; set; }
    }
}
