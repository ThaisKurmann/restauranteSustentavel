﻿namespace RestauranteSustentavel_BE.Models
{
    public class Bebida
    {
        public string nome { get; set; }
        public bool alcoolica { get; set; }

        public int id { get; set; }

        public float preco { get; set; }



    }
}
